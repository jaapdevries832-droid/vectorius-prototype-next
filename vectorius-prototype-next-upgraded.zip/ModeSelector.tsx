"use client";
import React from "react";

type Mode = "tutor" | "checker" | "explainer";

type Props = {
  mode: Mode;
  onChange: (m: Mode) => void;
};

export default function ModeSelector({ mode, onChange }: Props) {
  return (
    <div className="flex items-center gap-2 mb-3">
      {(["tutor", "checker", "explainer"] as Mode[]).map((m) => (
        <button
          key={m}
          onClick={() => onChange(m)}
          className={`px-3 py-1.5 rounded border text-sm ${
            mode === m ? "bg-gray-900 text-white" : "bg-white hover:bg-gray-50"
          }`}
        >
          {m}
        </button>
      ))}
    </div>
  );
}

